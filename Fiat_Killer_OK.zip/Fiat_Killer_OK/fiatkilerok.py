# Fiat Killer OK Cash edition by NuPulse 2017
# Based in the Nacho Cabanes original code "Mini Invaders"
# Music by Billy Korg (Tripping Gaia) 
# This software is absolute Open Source and free to use, modify or whatever you want. This product has no warranty at all.

import pygame
from pygame.locals import *
import random

pygame.init()
pygame.display.set_icon(pygame.image.load("okcashlogo.png"))
pygame.display.set_caption("FiatKiller - OK Cash Edition")

ancho = 800
alto = 600
cantidadMarcianos = 10



pantalla = pygame.display.set_mode( (ancho, alto) )
pygame.key.set_repeat(1,25)
reloj = pygame.time.Clock()

fondo = pygame.image.load("piramide.png")

#sonido
pygame.mixer.music.load("Tripping.ogg")
pygame.mixer.music.play(1)

sonidobtc = pygame.mixer.Sound("disparo.ogg")
sonidoexp = pygame.mixer.Sound("dolar.ogg")
sonidoclm = pygame.mixer.Sound("colminero.ogg")
interludio = pygame.mixer.Sound("Tripping.ogg")


imagenNave = pygame.image.load("raspberry-pi-3.png")
rectanguloNave = imagenNave.get_rect()
imagenUfo = pygame.image.load("oro.png")
rectanguloUfo = imagenUfo.get_rect()
imagenMarciano = pygame.image.load("dolarusa.png")
rectangulosMarcianos = { }
marcianosVisibles = { }
velocidadesX = { }
velocidadesY = { }
imagenDisparo = pygame.image.load("okcashlogo.png")
rectanguloDisparo = imagenDisparo.get_rect()
imagenPresent = pygame.image.load("piramide.png")
rectanguloPresent = imagenPresent.get_rect()
rectanguloPresent.top = 30
rectanguloPresent.left = 0

letra30 = pygame.font.SysFont("Arial", 30)
imagenTextoPresent = letra30.render("Press Space to Play or Esc to Quit", True, (200,200,200), (0,0,0))
rectanguloTextoPresent = imagenTextoPresent.get_rect()
rectanguloTextoPresent.centerx = pantalla.get_rect().centerx
rectanguloTextoPresent.centery = 520

letra18 = pygame.font.SysFont("Arial", 18)



partidaEnMarcha = True

while partidaEnMarcha:
	
	pantalla.fill( (0,0,0) )
	pantalla.blit(imagenPresent, rectanguloPresent)
	pantalla.blit(imagenTextoPresent, rectanguloTextoPresent)
	pygame.display.flip()
	entrarAlJuego = False
	while not entrarAlJuego:
		pygame.time.wait(100)
		for event in pygame.event.get(KEYUP):
			if event.key == K_SPACE:
				entrarAlJuego = True
				interludio.stop()
			if event.key == K_ESCAPE:
				pygame.quit()
	
	puntos = 0			
	pygame.mixer.music.stop()
	rectanguloNave.left = ancho / 2
	rectanguloNave.top = alto - 80
	rectanguloUfo.top = 30



	for i in range(0,cantidadMarcianos + 1):
		rectangulosMarcianos[i] = imagenMarciano.get_rect()
		rectangulosMarcianos[i].left = random.randrange(50,751)
		rectangulosMarcianos[i].top = random.randrange(10,301)
		marcianosVisibles[i] = True 
		velocidadesX[i] = 3
		velocidadesY[i] = 3
		
	
	disparoAcitivo = False 
	ufoVisible = True 
	terminado = False


	while not terminado:
		for event in pygame.event.get():
			if event.type == pygame.QUIT: 
				terminado = True
				partidaEnMarcha = False
		
		keys = pygame.key.get_pressed()
		if keys[K_LEFT]:
			rectanguloNave.left -= 8
		if keys[K_RIGHT]:
			rectanguloNave.left += 8
		if rectanguloNave.left < 0:
			rectanguloNave.left = 0
		if rectanguloNave.right > ancho:
			rectanguloNave.right = 800
			
		if keys[K_SPACE] and not disparoAcitivo:
			disparoAcitivo = True
			rectanguloDisparo.left = rectanguloNave.left + 18
			rectanguloDisparo.top = rectanguloNave.top -25
			sonidobtc.play()
			
		if keys[K_ESCAPE]:
			pygame.quit()
		
		for i in range(0,cantidadMarcianos+1):
			rectangulosMarcianos[i].left += velocidadesX[i]
			rectangulosMarcianos[i].top += velocidadesY[i]
			if rectangulosMarcianos[i].left < 0 or rectangulosMarcianos[i].right > ancho:
				velocidadesX[i] = -velocidadesX[i]
			if rectangulosMarcianos[i].top < 0 or rectangulosMarcianos[i].bottom > alto:
				velocidadesY[i] = -velocidadesY[i]
			
		
		rectanguloUfo.left += 2 
		if rectanguloUfo.right > ancho:
			rectanguloUfo.left = 0	
		
		if disparoAcitivo:
			rectanguloDisparo.top -= 6
			if rectanguloDisparo.top <= 0:
				disparoAcitivo = False
	
		for i in range(0,cantidadMarcianos+1):
			if marcianosVisibles[i]:
				if rectanguloNave.colliderect( rectangulosMarcianos[i] ):
					terminado = True	
					sonidoclm.play()
					pygame.time.delay(200)
					interludio.play()
					
					
				if disparoAcitivo:
					if rectanguloDisparo.colliderect( rectangulosMarcianos[i] ):
						marcianosVisibles[i] = False
						disparoAcitivo = False	
						sonidoexp.play()	
						puntos += 1			
						
		if disparoAcitivo:
			if rectanguloDisparo.colliderect ( rectanguloUfo ):
				ufoVisible = False
				disparoAcitivo = False
				sonidoexp.play()
				puntos += 5
				
		cantidadMarcianosVisibles = 0
		for i in range(0,cantidadMarcianos+1):
			if marcianosVisibles[i]:
				cantidadMarcianosVisibles = cantidadMarcianosVisibles + 1
				
		
		
		if not ufoVisible and cantidadMarcianosVisibles == 0:
			
			for i in range(0,cantidadMarcianos + 1):
				rectangulosMarcianos[i] = imagenMarciano.get_rect()
				rectangulosMarcianos[i].left = random.randrange(50,751)
				rectangulosMarcianos[i].top = random.randrange(10,301)
				marcianosVisibles[i] = True 
				velocidadesX[i] = 5
				velocidadesY[i] = 5
				
				ufoVisible = True
			  	
			 
		pantalla.fill ( (0,0,0) )
		pantalla.blit(fondo, (0,0))
		for i in range(0,cantidadMarcianos+1):
			if marcianosVisibles[i]:
				pantalla.blit(imagenMarciano, rectangulosMarcianos[i])
		pantalla.blit(imagenNave, rectanguloNave)
		imagenPuntos = letra18.render('OK Price $ '+str(puntos), True, (200,200,200), (0,0,0) )
		rectangulosPuntos = imagenPuntos.get_rect()
		rectangulosPuntos.left = 10
		rectangulosPuntos.top = 10
		pantalla.blit(imagenPuntos,rectangulosPuntos)
		
		
		if ufoVisible:
			pantalla.blit(imagenUfo, rectanguloUfo)
		if disparoAcitivo: 
			pantalla.blit(imagenDisparo, rectanguloDisparo)
	    
		pygame.display.flip()	
		
		reloj.tick(50)
		
pygame.quit()			


	
		
